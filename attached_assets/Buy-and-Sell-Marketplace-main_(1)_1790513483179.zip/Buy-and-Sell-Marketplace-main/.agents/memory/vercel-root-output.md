---
name: Vercel root compatibility
description: Deployment configuration for the marketplace when Vercel Root Directory differs between repository root and frontend artifact.
---

The marketplace keeps both repository-level and frontend-artifact-level Vercel configuration. The repository-level build mirrors the Vite output into a root `public` directory, while the artifact-level configuration serves `dist/public`.

**Why:** The original deployment built successfully but Vercel searched for a root `public` directory after the build. Vercel project Root Directory settings can also make the same path resolve from the frontend artifact.

**How to apply:** Preserve both configurations when moving or rebuilding the marketplace; do not assume the dashboard Root Directory is the repository root.